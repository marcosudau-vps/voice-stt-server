#!/usr/bin/env python3
from pathlib import Path
import subprocess
import sys

REPO = Path(r"P:\GithubRepos\marcosudau-vps\voice-stt-server\workspaces\einheitliche-triggerarchitektur-distributed")
SERVER = REPO / "api_fastapi_server" / "server.py"
EXPECTED_BRANCH = "review/AP-SRV-030/run-01"
EXPECTED_HEAD = "3e146533b81d220d4d176b5a4342cb2c8398a343"


def git(*args):
    proc = subprocess.run(
        ["git", *args], cwd=REPO, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr)
    return proc.stdout.strip()


def main():
    branch = git("branch", "--show-current")
    head = git("rev-parse", "HEAD")
    if branch != EXPECTED_BRANCH:
        raise RuntimeError("Falscher Branch: " + branch)
    if head != EXPECTED_HEAD:
        raise RuntimeError("Falscher HEAD: " + head)

    status = git("status", "--porcelain").replace("\\", "/")
    required_dirty = (
        "api_fastapi_server/server.py",
        "tests/unit/test_server_command_timer_e2e.py",
        "docs/einheitliche-triggerarchitektur.md",
        "docs/client-development/03-server-events-kurzreferenz.md",
    )
    for path in required_dirty:
        if path not in status:
            raise RuntimeError(
                "Erwartete uncommittete C3-Datei fehlt im Working Tree: " + path
            )

    text = SERVER.read_text(encoding="utf-8")
    for marker in (
        "self._registered_input_close_events = {}",
        "def _reserve_input_close_event(self, plan, *, recovery=False):",
        "def fail_closed_for_recovery(self, activation_id):",
        "Sitzung wird technisch beendet",
    ):
        if marker not in text:
            raise RuntimeError("C3-Marker fehlt: " + marker)

    old = (
        "        # The replay cache is session scoped by contract, so this is the one\n"
        "        # place it is released.\n"
        "        self._command_replay.clear()\n"
    )
    new = (
        "        # The replay cache is session scoped by contract, so this is the one\n"
        "        # place it is released.\n"
        "        self._command_replay.clear()\n"
        "\n"
        "        # C3/PHASE-05 terminal seal: recorder shutdown/abort may synchronously\n"
        "        # fire lifecycle callbacks before ``close()`` returns. Those callbacks\n"
        "        # may clean recording state, but they must never leave a terminal\n"
        "        # session looking reusable again. Recorder lifecycle callbacks are\n"
        "        # pinned to synchronous dispatch, so this is the final close\n"
        "        # linearization point.\n"
        "        with self.lock:\n"
        "            self.streaming = False\n"
        "            self.status = \"closed\"\n"
        "            self._wake_detection_epoch = None\n"
    )

    count = text.count(old)
    if count != 1:
        if "C3/PHASE-05 terminal seal" in text:
            print("Terminal seal ist bereits vorhanden; keine zweite Änderung.")
            return 0
        raise RuntimeError(
            "Erwartetes close()-Ende nicht eindeutig gefunden; Treffer: %d" % count
        )

    SERVER.write_text(text.replace(old, new, 1), encoding="utf-8")
    print("C3 terminal seal applied:")
    print(r"  api_fastapi_server\server.py")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        print("ABORTED: %s" % exc, file=sys.stderr)
        sys.exit(1)
