#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import re
import subprocess
import sys
import textwrap

REPO = Path(r"P:\GithubRepos\marcosudau-vps\voice-stt-server\workspaces\einheitliche-triggerarchitektur-distributed")
EXPECTED_BRANCH = "review/AP-SRV-030/run-01"
EXPECTED_HEAD = "3e146533b81d220d4d176b5a4342cb2c8398a343"

SERVER = REPO / "api_fastapi_server" / "server.py"
TESTS = REPO / "tests" / "unit" / "test_server_command_timer_e2e.py"
DOC = REPO / "docs" / "einheitliche-triggerarchitektur.md"
EVENT_DOC = REPO / "docs" / "client-development" / "03-server-events-kurzreferenz.md"
HERE = Path(__file__).resolve().parent


def git(*args):
    proc = subprocess.run(
        ["git", *args],
        cwd=REPO,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            "git %s failed (%s):\n%s"
            % (" ".join(args), proc.returncode, proc.stderr)
        )
    return proc.stdout.strip()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def method_bounds(text, method_name):
    pattern = re.compile(r"(?m)^    def " + re.escape(method_name) + r"\(")
    match = pattern.search(text)
    if not match:
        raise RuntimeError("method not found: " + method_name)
    start = match.start()
    next_member = re.compile(r"(?m)^    (?=(?:def |async def |@))").search(
        text, match.end()
    )
    end = next_member.start() if next_member else len(text)
    return start, end


def replace_method(text, method_name, replacement):
    start, end = method_bounds(text, method_name)
    replacement = textwrap.dedent(replacement).strip("\n")
    replacement = "\n".join(
        ("    " + line if line else "")
        for line in replacement.splitlines()
    )
    return text[:start] + replacement + "\n\n" + text[end:]


def insert_before(text, marker, block):
    pos = text.find(marker)
    if pos < 0:
        raise RuntimeError("insert marker not found: %r" % marker)
    block = textwrap.dedent(block).strip("\n") + "\n\n"
    return text[:pos] + block + text[pos:]


def exact_replace(text, old, new, label):
    count = text.count(old)
    if count != 1:
        raise RuntimeError(
            "%s: expected exactly one source block, found %s" % (label, count)
        )
    return text.replace(old, new, 1)


def template(name):
    return (HERE / name).read_text(encoding="utf-8")


def main():
    print("AP-SRV-030 C3 ROOT FIX - preflight")
    require(REPO.is_dir(), "Worktree not found: %s" % REPO)

    branch = git("branch", "--show-current")
    head = git("rev-parse", "HEAD")
    tracked_status = git("status", "--porcelain", "--untracked-files=no")

    require(branch == EXPECTED_BRANCH, "Wrong branch: " + branch)
    require(head == EXPECTED_HEAD, "Wrong HEAD: " + head)
    require(
        tracked_status == "",
        "Tracked working tree is not clean. Refusing to patch:\n"
        + tracked_status,
    )

    server = SERVER.read_text(encoding="utf-8")
    tests = TESTS.read_text(encoding="utf-8")
    doc = DOC.read_text(encoding="utf-8")
    event_doc = EVENT_DOC.read_text(encoding="utf-8")

    # C2 identity guards before any write.
    for marker in (
        "def _run_input_close(self, plan):",
        "def _run_recovery_close(self, plan):",
        "def fail_closed_for_recovery(self, activation_id):",
        "self._wake_detection_epoch = None",
        "class RecoveryFailClosedEndToEndTests",
        "test_recovery_cleanup_failure_never_publishes_idle_or_admits_new_activation",
    ):
        require(marker in (server + "\n" + tests), "C2 marker missing: " + marker)

    init_old = (
        "        self._wake_detection_epoch = None\n"
        "        # Session-scoped command idempotency. The contract requires the replay\n"
    )
    init_new = (
        "        self._wake_detection_epoch = None\n"
        "        # PHASE-04 / C3: the exactly-once input-close lifecycle event is\n"
        "        # logically reserved before the foreground slot may become idle.\n"
        "        # AP-SRV-040 will bind this seam to eventId/eventSeq/stateVersion.\n"
        "        self._registered_input_close_events = {}\n"
        "        # Session-scoped command idempotency. The contract requires the replay\n"
    )
    server = exact_replace(
        server, init_old, init_new, "session event-registry init"
    )

    server = replace_method(
        server,
        "_run_input_close",
        template("TPL_server_input_close.py.txt"),
    )
    server = replace_method(
        server,
        "_run_recovery_close",
        template("TPL_server_recovery.py.txt"),
    )
    server = replace_method(
        server,
        "fail_closed_for_recovery",
        template("TPL_server_fail_closed.py.txt"),
    )

    tests = insert_before(
        tests,
        '@unittest.skipIf(TestClient is None, "FastAPI test client is not installed")\n'
        "class RecoveryIdentityEndToEndTests",
        template("TPL_test_event_registration.py.txt"),
    )
    tests = replace_method(
        tests,
        "test_recovery_cleanup_failure_never_publishes_idle_or_admits_new_activation",
        template("TPL_test_t16.py.txt"),
    )

    doc_old = (
        "2. **Phase B (physischer Input-Close)** - läuft **außerhalb** beider Locks:\n"
        "   Gate schließen, Recorder stoppen/flushen, Ledger-Input-Close registrieren,\n"
        "   und erst danach wird die noch aktuelle identische Activation\n"
        "   identitätsgebunden mit `input_closed()` auf `idle` gesetzt. Das\n"
        "   Lifecycle-Event folgt erst nach Lockfreigabe.\n"
    )
    doc_new = (
        "2. **Phase B (physischer Input-Close)** - läuft **außerhalb** beider Locks:\n"
        "   Gate schließen, Recorder stoppen/flushen, Ledger-Input-Close registrieren\n"
        "   und das genau-einmal Lifecycle-Ereignis **logisch registrieren**. Erst\n"
        "   danach wird die noch aktuelle identische Activation identitätsgebunden mit\n"
        "   `input_closed()` auf `idle` gesetzt. Die Transportpublikation des bereits\n"
        "   registrierten Events folgt nach Lockfreigabe.\n"
    )
    doc = exact_replace(
        doc, doc_old, doc_new, "two-phase close documentation"
    )

    fail_old = (
        "- Kann selbst der harte Recorder-Abbruch keinen sicheren Zustand herstellen,\n"
        "  geht die Session **fail-closed**: kein `idle`, keine neue Activation, Audio\n"
        "  gilt als nicht verfügbar, kein erfolgreicher Abschluss wird behauptet.\n"
    )
    fail_new = (
        "- Kann selbst der harte Recorder-Abbruch keinen sicheren Zustand herstellen,\n"
        "  bleibt die Session **nicht** dauerhaft in `closing_input`: sie wird über den\n"
        "  bestehenden Session-Close-Pfad technisch beendet. Es wird kein wieder\n"
        "  benutzbares `idle` behauptet; offene Ledgerarbeit wird cancel-/terminalisiert\n"
        "  und eine neue Session muss aufgebaut werden.\n"
    )
    doc = exact_replace(
        doc, fail_old, fail_new, "recovery terminalization documentation"
    )

    event_old = (
        "`activation_closed` wird erst ausgelöst, wenn Gate und Recorder tatsächlich\n"
        "geschlossen sind (zweiphasiger Input-Close, AP-SRV-030 C2). `causedByCommandId`\n"
        "trägt nur bei einem normalen, kommandogetriebenen `finish`/`cancel` die\n"
    )
    event_new = (
        "`activation_closed` wird erst logisch registriert, wenn Gate und Recorder\n"
        "tatsächlich geschlossen und die Ledgerausgänge registriert sind\n"
        "(zweiphasiger Input-Close, AP-SRV-030 C3). Diese Registrierung liegt vor der\n"
        "Foreground-Freigabe nach `idle`; die Transportpublikation kann unmittelbar\n"
        "danach erfolgen. `causedByCommandId` trägt nur bei einem normalen,\n"
        "kommandogetriebenen `finish`/`cancel` die\n"
    )
    event_doc = exact_replace(
        event_doc, event_old, event_new, "event documentation"
    )

    # All expected source blocks have been validated before the first write.
    SERVER.write_text(server, encoding="utf-8")
    TESTS.write_text(tests, encoding="utf-8")
    DOC.write_text(doc, encoding="utf-8")
    EVENT_DOC.write_text(event_doc, encoding="utf-8")

    print("")
    print("C3 ROOT FIX APPLIED")
    print("Changed:")
    for path in (SERVER, TESTS, DOC, EVENT_DOC):
        print("  " + str(path.relative_to(REPO)))
    print("No commit created by apply script.")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        print("\nABORTED: %s" % exc, file=sys.stderr)
        sys.exit(1)
