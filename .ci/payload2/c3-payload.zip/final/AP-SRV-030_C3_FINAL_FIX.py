#!/usr/bin/env python3
from pathlib import Path
import subprocess
import sys

REPO = Path(r"P:\GithubRepos\marcosudau-vps\voice-stt-server\workspaces\einheitliche-triggerarchitektur-distributed")
SERVER = REPO / "api_fastapi_server" / "server.py"
TESTS = REPO / "tests" / "unit" / "test_server_command_timer_e2e.py"
HERE = Path(__file__).resolve().parent

EXPECTED_BRANCH = "review/AP-SRV-030/run-01"
EXPECTED_HEAD = "3e146533b81d220d4d176b5a4342cb2c8398a343"


def git(*args):
    p = subprocess.run(
        ["git", *args],
        cwd=REPO,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if p.returncode:
        raise RuntimeError(p.stderr)
    return p.stdout.strip()


def require(cond, msg):
    if not cond:
        raise RuntimeError(msg)


def main():
    require(REPO.is_dir(), "Worktree fehlt: %s" % REPO)
    require(
        git("branch", "--show-current") == EXPECTED_BRANCH,
        "Falscher Branch",
    )
    require(git("rev-parse", "HEAD") == EXPECTED_HEAD, "Falscher HEAD")

    server = SERVER.read_text(encoding="utf-8")
    tests = TESTS.read_text(encoding="utf-8")

    # Continue from the already-applied, intentionally dirty C3 worktree.
    for marker in (
        "self._registered_input_close_events = {}",
        "def _reserve_input_close_event(self, plan, *, recovery=False):",
        "def fail_closed_for_recovery(self, activation_id):",
        "C3/PHASE-05 terminal seal",
    ):
        require(marker in server, "Erwarteter C3-Marker fehlt: " + marker)

    require(
        "class CloseEventRegistrationEndToEndTests" in tests,
        "C3 PHASE-04 Test fehlt",
    )
    require(
        "Unrecoverable input cleanup terminates the session instead of hanging."
        in tests,
        "C3 PHASE-05 Teststand fehlt",
    )

    old_publish = (HERE / "TPL_publish_status_old.txt").read_text(encoding="utf-8")
    new_publish = (HERE / "TPL_publish_status_new.txt").read_text(encoding="utf-8")

    if old_publish in server:
        server = server.replace(old_publish, new_publish, 1)
    elif "closed`` is terminal" not in server and "stale non-closed publish" not in server:
        raise RuntimeError(
            "publish_status() entspricht nicht dem erwarteten C2/C3-Stand"
        )

    # Make T16 prove the exact stale-timer race, not merely observe close()
    # before the timer worker resumes.
    anchor = (
        "                server.close = observed_close\n"
        "\n"
        "                opened = server.handle_trigger_command({\n"
    )
    replacement = (
        "                server.close = observed_close\n"
        "\n"
        "                stale_waiting_publish_attempted = threading.Event()\n"
        "                original_publish_status = server.publish_status\n"
        "\n"
        "                def observed_publish_status(state=None):\n"
        "                    if (\n"
        "                        terminated.is_set()\n"
        "                        and state in {\"listening\", \"wakeword_wait\"}\n"
        "                    ):\n"
        "                        stale_waiting_publish_attempted.set()\n"
        "                    return original_publish_status(state)\n"
        "\n"
        "                server.publish_status = observed_publish_status\n"
        "\n"
        "                opened = server.handle_trigger_command({\n"
    )
    if anchor in tests:
        tests = tests.replace(anchor, replacement, 1)
    elif "stale_waiting_publish_attempted = threading.Event()" not in tests:
        raise RuntimeError("T16 Instrumentierungsanker nicht gefunden")

    anchor2 = (
        "                self.assertTrue(terminated.wait(timeout=20))\n"
        "                self.assertEqual(server.status, \"closed\")\n"
    )
    replacement2 = (
        "                self.assertTrue(terminated.wait(timeout=20))\n"
        "                # Wait until the recovery timer worker has resumed and\n"
        "                # attempted to publish the waiting state it calculated\n"
        "                # before fail_closed_for_recovery(). The terminal guard\n"
        "                # must make that stale publication inert.\n"
        "                self.assertTrue(\n"
        "                    stale_waiting_publish_attempted.wait(timeout=20)\n"
        "                )\n"
        "                self.assertEqual(server.status, \"closed\")\n"
    )
    if anchor2 in tests:
        tests = tests.replace(anchor2, replacement2, 1)
    elif "stale_waiting_publish_attempted.wait(timeout=20)" not in tests:
        raise RuntimeError("T16 Assertion-Anker nicht gefunden")

    SERVER.write_text(server, encoding="utf-8")
    TESTS.write_text(tests, encoding="utf-8")

    print("FINAL C3 ROOT FIX APPLIED")
    print(r"  api_fastapi_server\server.py")
    print(r"  tests\unit\test_server_command_timer_e2e.py")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        print("ABORTED: %s" % exc, file=sys.stderr)
        sys.exit(1)
